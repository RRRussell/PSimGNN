import os
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

path = "./IMDBMulti/More_than_15/"

to_path = "./IMDBMulti/Less_than_5/"

# d = []
nodes = []
edges = []
for g_file in os.listdir(to_path):
    g = nx.read_gexf(path+g_file)
    # print("gid:",g_file)
    # print("density:",len(g.edges())/len(g.nodes()))
    # d.append(len(g.edges())/len(g.nodes()))
    # density = len(g.edges())/len(g.nodes())
    nodes.append(len(g.nodes()))
    edges.append(len(g.edges()))
    # if density<= 5:
    # 	nx.write_gexf(g, to_path+g_file)
# data=np.array(d)
# plt.hist(data)
# plt.show()
nodes = np.array(nodes)
edges = np.array(edges)
print(np.max(nodes))
print(np.min(nodes))
print(np.mean(nodes))
print(np.max(edges))
print(np.min(edges))
print(np.mean(edges))

